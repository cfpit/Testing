package ar.edu.centro8.desarrollo.proyectojpa1an;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Proyectojpa1anApplication {

	public static void main(String[] args) {
		SpringApplication.run(Proyectojpa1anApplication.class, args);
	}

}
