package condicionales;

public class Test {
    public static void main(String[] args) {
        int edad = 30;
        
        if (edad >= 18) {
            System.out.println("Sos mayor de edad");
        } else {
            System.out.println("Sos menor de edad");
        }
    }
}
