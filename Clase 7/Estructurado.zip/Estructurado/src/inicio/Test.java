package inicio;

public class Test {
    public static void main(String[] args) {
        System.out.println("Hola Mundo");
        
        //variables
        String frase = "Me encanta Java!";
        int edad = 35;
        double altura = 1.78;
        boolean abierto = false;
        final double PI = 3.14;//final = constante
        
        //impresion de valores
        System.out.println("Hola, tengo " + edad + " anios y mi altura es de " + altura + " metros");
        
        
        
        
    }
}
