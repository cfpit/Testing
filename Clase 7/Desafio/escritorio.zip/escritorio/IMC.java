


public class IMC {
    public static void main(String[] args) {
        // Verificar si hay suficientes argumentos
        if (args.length != 2) {
            System.err.println("Uso correcto: java CalculadoraIMC <peso> <altura>");
            System.exit(1);
        }

        // Convertir strings a doubles
        try {
            double peso = Double.parseDouble(args[0]);
            double altura = Double.parseDouble(args[1]);

            // Calcular el IMC
            double imc = calcularIMC(peso, altura);

            // Mostrar el resultado
            System.out.printf("El IMC es: %.2f%n", imc);
            mostrarCategoriaIMC(imc);
        } catch (NumberFormatException e) {
            System.err.println("Error: Los argumentos deben ser números válidos.");
            System.exit(1);
        }
    }

    /**
     * Calcula el IMC basado en el peso y la altura.
     *
     * @param peso Peso en kilogramos
     * @param altura Altura en metros
     * @return El IMC calculado
     */
    private static double calcularIMC(double peso, double altura) {
        return peso / Math.pow(altura, 2);
    }

    /**
     * Determina la categoría del IMC.
     *
     * @param imc Valor del IMC
     */
    private static void mostrarCategoriaIMC(double imc) {
        String categoria;
        if (imc < 18.5) {
            categoria = "Bajo";
        } else if (imc < 25) {
            categoria = "Normal";
        } else if (imc < 30) {
            categoria = "Sobrepeso";
        } else if (imc < 35) {
            categoria = "Obesidad";
        } else {
            categoria = "Obesidad Severa";
        }
        System.out.println("La categoría es: " + categoria);
    }
}

